<?php include("includes/header.php"); ?>
<h1><img src="http://m.providence.edu/library/images/logo.gif" alt="" />
August Hours at <br /> Providence College Library</h1>

<div id="content">
<h3>Phillips Memorial Library has the following hours during from August 1 - September 6</h3><br /> 
<p>&nbsp;</p>
<h2>Hours 8/1 - 9/6</h2>
<br />
The Library is open and <a class="call" href="tel:4018651993" accesskey="2">circulation</a> is available<br />
<br />
<ul class="hour">
<li>Monday - Friday  	8:30 a - 4:30 p </li>
<li>Closed Weekends</li></ul>
<p>&nbsp;</p>
<a class="call" href="http://m.providence.edu/library/semesterhours.php">Regular Hours</a> resume 9/7/10.
<p>&nbsp;</p>
</div>
<?php include("includes/footer.php"); ?>
