<?php include("includes/header.php"); ?>
Library <br />Holidays</h1>

<div id="content">
<h2>Thanksgiving Week</h2>
<ul>
<li>Wednesday, November 24                      Closed</li>
<li>Thursday, November 25  	               Closed</li>
<li>Friday, November 26   	               Closed</li>
<li>Saturday, November 27   	               Noon - 5p</li>
<li>Sunday, November 28   	               Noon - 2a</li>
</ul>
</div>
<?php include("includes/footer.php"); ?>