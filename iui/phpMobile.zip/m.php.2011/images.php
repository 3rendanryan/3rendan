<?php include("includes/header.php"); ?>
Mobile  <br /> Images</h1>

<div id="content">
<h2>Image credits:</h2>
<div id='nav'>
<ul>
<li class= 'hours'> http://openclipart.org/media/files/dustin_w/14189 Accessed 9.3.09</li>
<li class= 'faq'> self</li>
<li class= 'maps'> http://openclipart.org/media/files/Anonymous/13028 Accessed 9.3.09</li>
<li class= 'renewals'> http://openclipart.org/people/Todd7/Todd7_book.svg Accessed 9.3.09</li>
<li class= 'directions'> http://openclipart.org/media/files/ryanlerch/1087 Accessed 9.2.09</li>
<li class= 'bookstore http://openclipart.org/people/Todd7/Todd7_book.svg Accessed 9.3.09</li>
<li class= 'helin'> http://providence.edu/Academics/Phillips+Memorial+Library/ Accessed 9.3.09</li>
<li class= 'card*http://openclipart.org/media/files/Anonymous/7227 Accessed 9.3.09</li>
<li class= 'community'> http://openclipart.org/media/files/FunDraw_dot_com/3704 Accessed 9.3.09</li>
<li class= 'access'> http://openclipart.org/media/files/FunDraw_dot_com/3704 Accessed 9.3.09</li>
<li class= 'writing'> http://openclipart.org/media/files/nicubunu/11282 Accessed 12.13.09 </li>
<li class= 'oas'> http://openclipart.org/people/snifty/snifty_Spiral_notebook.svg Accessed 12.13.09 </li>
<li class= 'ebsco'> http://www.ebscohost.com/ Accessed 12.13.09</li>
<li class= 'txt'> http://openclipart.org/media/files/ytknick/8927 Accessed 12.29.09</li>
<li class= 'archives'> http://openclipart.org/people/jantonalcor/jantonalcor_Book.svg Accessed 1.5.09</li>
</ul>
</div>
<p>&nbsp;</p>
<h2>All images edited for size and composition in PhotoShop CS4 by <a href="mailto:bryan1@providence.edu">Brendan Ryan</a>.</h2>
</div>
<?php include("includes/footer.php"); ?>

