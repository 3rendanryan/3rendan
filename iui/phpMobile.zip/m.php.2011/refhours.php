<?php include("includes/header.php"); ?>
Reference <br />Desk Hours</h1> 
<div id="content">
<h2>Reference: </h2>      
<ul class="main">
<li>Monday - Friday 	8:30 a - 10 p      </li>
<li>Saturday  	12 p - 6 p </li>
<li>Sunday  	2 p - 10 p </li>
</ul>
<p>&nbsp;</p>
<a class="call" href="tel:4018652581">Call Reference</a><br />
</div>
<?php include("includes/footer.php"); ?>
