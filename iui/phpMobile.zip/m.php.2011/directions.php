<?php include("includes/header.php"); ?>
Directions <br/> to the Library</h1>
<div id="content">
    <div id="nav">
        <ul>
        <li>From the main (Cunningham Avenue) entrance to the college: <br />
        Turn right after the guard house. Proceed up the hill; park as close to the top of the hill as possible. The library is the building at the top of the hill. Follow the sidewalk to the left of the library to enter through the front door. <br />
        <br /></li>
        <li><a class="linkButton" href="pc-directions.php"> Directions to Providence College</a></li>
        </ul>
    </div>
</div>
<?php include("includes/footer.php"); ?>
