<?php include("includes/header.php"); ?>

Thank <br />You</h1>  

<div id="content">
	<h4>Thank you!  You'll recieve a response shortly.</h4>
</div>
<?php include("includes/footer.php"); ?>