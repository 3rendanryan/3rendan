<?php include("includes/header.php"); ?>

Where is <br />it?</h1>

<div id="content">
<h2>Course Reserves: 
Ask at the circulation desk on the 1st floor</h2><br/>
<h2>E-Reserves:  
Help accessing them is available at the Reference Desk on the 1st floor</h2><br/>
<h2>Staplers: 
Circulation desk, InTeLeR Station, Reference Desk</h2><br />
<h2>Pencil Sharpener:
Circulation desk</h2><br />
<h2>Handicap accessible restrooms:  
1st floor</h2><br/>
<h2>Group study room with projector:  
Lower Level 04</h2><br />
<h2>InTeLeR station: 2nd floor</h2><br/>
<h2>Government Documents: 1st floor</h2><br/>
</div>
<?php include("includes/footer.php"); ?>
