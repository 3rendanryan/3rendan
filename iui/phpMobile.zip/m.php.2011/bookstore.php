<?php include("includes/header.php"); ?>
Bookstore <br />Information</h1>

<div id="content">
The Providence College bookstore is located on the lower level of the Slavin Center.<br />  
<p>&nbsp;</p>
<a class="linkButton" href="http://www.providence.edu/NR/rdonlyres/322DA469-892B-46C3-BB5B-4707BEC792AD/8750/campus_map.pdf">Campus Map</a>
<br />
<br />
<h2>PC Bookstore Hours</h2>
<ul class="hour">
<li>Monday - Wednesday  	9 a -  7p </li>
<li>Thursday  	9 a - 5 p </li>
<li>Friday  	9 a - 4 p </li>
<li>Saturday  	11 a - 3 a </li>
<li>Sunday      CLOSED</li>
</ul>
<h2><a class="call" href="tel:4018652181">Call the bookstore</a></h2>
<br />
</div>
<?php include("includes/footer.php"); ?>