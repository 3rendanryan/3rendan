<?php include("includes/header.php"); ?>
Materials <br />Access</h1>    

<div id="content">
     <p>Often patrons cannot access services remotely or reserve books online because their card has expired.  All cards issued by Providence College expire in order to ensure the currency of record information.</p>
<p>&nbsp;</p>
<p>Please call the <a class="call" href="tel:4018651993" accesskey="2">circulation desk for assistance</a>.  This matter can often be resolved over the phone.</p>
</div>
<?php include("includes/footer.php"); ?>
