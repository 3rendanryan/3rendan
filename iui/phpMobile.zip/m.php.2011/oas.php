<?php include("includes/header.php"); ?>
The Office of <br />Academic Services</h1>

<div id="content">
The OAS is available to assist all PC students through a combination of academic and personal development programming.  <br />
<h2>Services include the following:</h2>
<ul>
<li>Academic Mentoring </li>
<li>Academic Monitoring</li>
<li>Academic Skills Workshops/Materials</li>
<li>Disability Support/Accommodations</li>
<li>Student-Athlete Academic Support/Life Skills Programming</li>
<li>Tutorial Assistance</li>
<li>Writing Assistance</li></ul>
<p>&nbsp;</p>
<a class="call" href="tel:4018652494" accesskey="0">Call the OAS</a>
<p>&nbsp;</p>
<a class="call" href="tel:4018652855" accesskey="0">Call the Tutoring / Writing Center</a>
<p>&nbsp;</p>
</div>
<?php include("includes/footer.php"); ?>