<?php include("includes/header.php"); ?>
<h1><img src="http://m.providence.edu/library/images/logo.gif"  alt=""  />Winter <br />Break</h1>

<div id="content">
<h2>Winter Break Hours : 12.24 - 1.17</h2>
<ul>
<li>Friday, December 24		-	Closed</li>
<li>Saturday, December 25	-	Closed</li>
<li>Sunday, December 26		-	Closed</li>
<li>Monday, December 27	-	Closed</li>
<li>Tuesday, December 28	-	8:30a - 4:30p</li>
<li>Wednesday, December 29	-	8:30a - 4:30p</li>
<li>Thursday, December 30	-	Closed</li>
<li>Friday, December 31		-	Closed</li>
<li>Saturday, January 1		-	Closed</li>
<li>Sunday, January 2		-	Closed</li>
<li>Monday, January 3		-	8:30a - 6p</li>
<li>Tuesday, January 4		-	8:30a - 6p</li>
<li>Wednesday, January 5	-	8:30a - 6p</li>
<li>Thursday, January 6		-	8:30a - 6p</li>
<li>Friday, January 7		-	8:30a - 6p</li>
<li>Saturday, January 8		-	Closed</li>
<li>Sunday, January 9		-	Closed</li>
<li>Monday, January 10		-	8:30a - 7p</li>
<li>Tuesday, January 11		-	8:30a - 7p</li>
<li>Wednesday, January 12	-	8:30a - 7p</li>
<li>Thursday, January 13		-	8:30a - 7p</li>
<li>Friday, January 14		-	8:30a - 7p</li>
<li>Saturday, January 15		-	Closed</li>
<li>Sunday, January 16		-	Closed</li>
<li>Monday, January 17		- 	Noon  -  2a</li>
</ul>
</div>
<?php include("includes/footer.php"); ?>
