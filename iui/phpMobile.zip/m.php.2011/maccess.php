<?php include("includes/header.php"); ?>
 Materials <br />Access</h1>

<div id="content">
    <p>Providence College undergraduates, continuing education students, graduate students, staff, clergy, and faculty can all borrow books and use the Brown University and HELIN systems for inter-library loans.</p>
    <p>&nbsp;</p>
    <p> Persons with alumni cards, special cards, and retired PC faculty and staff can borrow books from the Phillips Memorial Library.</p>
</div>
<?php include("includes/footer.php"); ?>
