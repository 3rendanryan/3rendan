<?php include("includes/header.php"); ?>
Easter <br />Break</h1>

<div id="content">
    <div id="nav">
            <ul>
            <li><h2>Easter Recess : 4.20 - 4.25</h2></li>
            <li>Wednesday, April 20  8a - 10p</li>
            <li>Thursday, April 21  8:30a - 4:30 p </li>
            <li>Friday, April 22  Closed
            <li>Saturday, April 23  Closed
            <li>Sunday, April 24  Closed
            <li>Monday, April 25  8:30a  -  2:00a
            </ul>
    </div>
</div>
<?php include("includes/footer.php"); ?>
