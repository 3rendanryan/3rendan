<?php include("includes/header.php"); ?>

Providence College <br />Library Hours</h1>

<div id="content">
<h3>Phillips Memorial Library has the following hours during the semester<br /> 
<p>&nbsp;</p>
<a class="call" href="holidays.php">Holiday exceptions.</a></h3>
<br />
The Library is open and <a class="call" href="tel:4018651993" accesskey="2">circulation</a> is available<br />
<br />
<ul class="hour">
<li>Monday - Thursday   	8 a - 2 a </li>
<li>Friday  	9 a - 10 p </li>
<li>Saturday  	9 a - 10 p </li>
<li>Sunday  	9 a - 2 a</li></ul>
<p>&nbsp;</p>
<a class="call" href="http://m.providence.edu/library/august.php">August Hours</a>
<p>&nbsp;</p>
</div>
<?php include("includes/footer.php"); ?>
