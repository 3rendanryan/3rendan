<?php
    function get_title($title) {
        
        return $title;
        
    }

?>