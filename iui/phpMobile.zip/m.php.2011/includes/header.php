<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
        <meta name="viewport" content="width = device-width" />
        <meta name="apple-mobile-web-app-capable" content="yes" />
        <meta name="apple-mobile-web-app-status-bar-style" content="black" />
        <title><?php echo $title; ?></title>
            <link rel="stylesheet" type="text/css" media="Screen" href="stylesheets/i.css" />
            <link rel="stylesheet" type="text/css" media="handheld" href="stylesheets/m.css" />
    </head>
<body>
    <h1><img src="stylesheets/images/logo.gif" height="65px" width="65px" alt=""  /> 