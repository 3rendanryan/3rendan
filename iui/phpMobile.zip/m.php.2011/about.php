<?php include("includes/header.php"); ?>
About Phillips Memorial <br /> Library Mobile</h1>

<div id="content">
Mobile Phillips Library was created by <br />
<p>&nbsp;</p>
<a class="call" href="mailto:bryan1@providence.edu">Brendan Ryan</a>.<br>
<p>&nbsp;</p>  
The images used on the upper left of the page are the property of Providence College. Some other images were acquired from the Open Clip Art Library (http://www.openclipart.org/). <br />
<p>&nbsp;</p>
<h2><a class="call" href="images.php" accesskey="1">Image credits</a></h2>
<p>&nbsp;</p>
</div>
<?php include("includes/footer.php"); ?>
