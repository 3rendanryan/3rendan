<?php include("includes/header.php"); ?>

Providence College <br />Library Hours</h1>
<div id='content'>
    <div id="nav">
        <ul>
            <h2>The Library is open and <a class="call" href="tel:4018651993" accesskey="2">circulation</a> is available<br /></h2>
            <br />
            <li>Monday - Thursday  	8 a - 2 a </li>
            <li>Friday  	8 a - 10 p </li>
            <li>Saturday  	9 a - 10 p </li>
            <li>Sunday  	9 a - 2 a</li></ul>
        <p>&nbsp;</p>
        <ul>
            <h2>A<a class="call" href="4018652581">Reference</a>Librarian is avaible to assist you.</h2>
            <br />
            <li>Monday - Friday 	8:30 a - 10 p</li>
            <li>Saturday  	12 p - 6 p </li>
            <li>Sunday  	2 p - 10 p </li>
        </ul>
        <ul>
            <h2>Holiday Hours</h2>
            <a class="linkButton" href="easter.php">Easter Recess : 4.20 - 4.25</a>
            <br />
            <p>&nbsp;</p>
            <a class="linkButton" href="exam.php">Exam / Reading Period</a>
            <br />
            <p>&nbsp;</p>
        </ul>
    </div>
</div>
<?php include("includes/footer.php"); ?>
